public class A {
    static private class Inner extends B {
    }
}

