package test;

public class ContainsOnlyInner {
    void method1() {
        System.out.println(Outer.Inner.class);
    }    
}

